# sphinx-multilingual
Add capabilities to manage multilingual in Sphinx template
